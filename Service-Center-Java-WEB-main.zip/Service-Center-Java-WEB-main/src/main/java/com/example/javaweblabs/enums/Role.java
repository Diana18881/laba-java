package com.example.javaweblabs.enums;

public enum Role {
    USER,
    MANAGER,
    MASTER
}
